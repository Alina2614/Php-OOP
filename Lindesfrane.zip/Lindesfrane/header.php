<?php
    require_once("includes.php");
?>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <!--<a class="navbar-brand" href="#">WebSiteName</a>-->
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">Page 1</a></li>
            <li><a href="#">Page 2</a></li>
            <li><a href="#">Page 3</a></li>
        </ul>
    </div>
</nav>
<div class="container">
    <div class="jumbotron">
        <h2>Welcome to</h2>
        <h1>Lindisfarne Safari Park</h1>
    </div>
</div>