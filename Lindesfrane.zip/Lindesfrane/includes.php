<link href="http://localhost/Lindesfrane/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<!--<link href="css/style.css" rel="stylesheet" type="text/css">-->
<link href="http://localhost/Lindesfrane/css/material-design-switch.css" rel="stylesheet" type="text/css">


<!-- Javascript -->
<script type="text/javascript" src="http://localhost/Lindesfrane/js/jquery-3.2.1.min.js"></script>