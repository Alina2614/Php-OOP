<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="calender/css/clndr.css">
		<link href="http://localhost/Lindesfrane/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<!--<link href="css/style.css" rel="stylesheet" type="text/css">-->
		<link href="http://localhost/Lindesfrane/css/material-design-switch.css" rel="stylesheet" type="text/css">
	</head>

<!-- Javascript -->
<script type="text/javascript" src="http://localhost/Lindesfrane/js/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script src="calender/js/clndr.js"></script>
    <script src="calender/js/demo.js"></script>
<html>