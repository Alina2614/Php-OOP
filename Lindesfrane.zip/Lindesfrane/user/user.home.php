<?php
	include "includes.php";
?>

<div class="container">
    <div class="jumbotron">
        <h2>Welcome to</h2>
        <h1>Lindisfarne Safari Park</h1>
    </div>
	<div class="cal1"></div>
</div>